from my_module import a
print(a)
