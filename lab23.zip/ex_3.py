from constant import g
def energy(m, h, v):
  U=m*g*h
  K=(m*v**2)/2
  E=U+K
  print(E)
energy(9,10,6)

