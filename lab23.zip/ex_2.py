
def mult_func(a):
  a0=1
  for i in a:
    a0=a0*i
  print(a0)
mult_func([2,3,5,10])
a=[1,3,4]
mult_func(a)
