def mult_func(n):
  y = x**2
  for i in range(a,len(n),b):
    y = x**2[i]
    return y
