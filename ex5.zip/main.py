from my_module import graviry_constant as G
g = 500*G/10*2
print(g)