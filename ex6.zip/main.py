from my_module_1 import a
from my_module_2 import a
print(a)
import my_module_1
import my_module_2
print(my_module_1.a*my_module_2.a)